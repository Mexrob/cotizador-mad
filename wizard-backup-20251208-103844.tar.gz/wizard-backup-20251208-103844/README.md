# Wizard Backup - 2025-12-08

Este backup contiene todos los archivos relacionados con el wizard y configurador de productos que fueron eliminados del proyecto.

## Contenido

### Componentes de Aplicación
- test-wizard/ - Página del wizard de prueba
- product-configurator.tsx - Componente principal del configurador de productos
- product-selector-dialog.tsx - Diálogo selector de productos

### Imágenes
- images-lines/ - Imágenes de líneas de producto (Vidrio)
- images-tones/ - Imágenes de colores/tonos (Blanco, Paja, Capuchino, Humo, Gris, Rojo, Negro)
- images-handles/ - Imágenes de jaladeras (Sorento A, L, G)

### Scripts
- Scripts para actualizar imágenes y entradas de base de datos

### Documentación
- Wizard Layout Adjustments.md - Historial completo de conversación del desarrollo

## Configuración del Wizard

El wizard estaba configurado con:
- **Línea de Producto**: Solo Vidrio
- **Jaladeras**: Sorento A, Sorento L, Sorento G
- **Tonos/Colores**: 
  - Blanco Brillante / Blanco Mate
  - Paja Brillante / Paja Mate
  - Capuchino Brillante / Capuchino Mate
  - Humo Brillante / Humo Mate
  - Gris Brillante / Gris Mate
  - Rojo Brillante / Rojo Mate
  - Negro Brillante / Negro Mate

## Características Adicionales
- Producto de Exhibición (+$500 MXN)
- Entrega Express (+$500 MXN)
- Cubrecanto (similar al tono del vidrio)

## Fecha de Backup
Creado: 2025-12-08 10:38:44
Actualizado: 2025-12-08 10:50:00 (agregado product-selector-dialog.tsx)
